// HelloBoost.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <boost/array.hpp>
#include <boost/regex.hpp>

int _tmain(int argc, _TCHAR* argv[])
{
  boost::array<int, 10> a;
  boost::smatch s;

  getchar();
	return 0;
}

