#pragma once

#include "targetver.h"

#include <iostream>
#include <string>
#include <ctime>
using namespace std;

#include <boost/signals2.hpp>
#include <boost/bind.hpp>
#include <boost/smart_ptr.hpp>
using namespace boost;
using namespace boost::signals2;