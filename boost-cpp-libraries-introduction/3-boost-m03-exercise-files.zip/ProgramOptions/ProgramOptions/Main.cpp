#include "stdafx.h"
#include "Fundamentals.hpp"
#include "Customization.hpp"

int main(int argc, char* argv[])
{
  return customization(argc, argv);
}